# Documentのschema適合判定を担うサブドメイン：sd-validation

## 概要

- Document の content が schema に適合するかを判定する業務領域。適合検証は確立された既製の仕組みで賄える一般的な関心事。

---

## サブドメイン分類

### 分類

一般

### 根拠

- JSON Schema 適合検証は業界標準の既製ライブラリで解決済みであり、waffle 固有の差別化を生まない。ゆえに一般。

---

## 業務ユースケース一覧

- uc-validate-document

---

## 詳細設計ガイド

- 一般ゆえ既製ライブラリを薄く包む。適合判定そのものは既製の検証器に委ね、waffle はエラー整形と境界の適応だけを担う。

---

## 外部解決策

jsonschema ライブラリを採用する（@stack:schema-validation の能力に当たる）。適合判定と違反詳細の抽出を委ねる。
